namespace TestPackage1
{
    public interface IMultiInstance
    {
        
    }

    public class Instance1 : IMultiInstance
    {
        
    }

    public class Instance2 : IMultiInstance
    {
        
    }
}