namespace TestPackage1
{
    public interface IOpenType<T>
    {   
    }

    public class OpenType<T> : IOpenType<T>
    {
    }
}